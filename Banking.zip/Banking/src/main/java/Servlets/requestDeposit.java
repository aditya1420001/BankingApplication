package Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.*;

/**
 * Servlet implementation class requestDeposit
 */
public class requestDeposit extends HttpServlet {
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();

		/*
		 * Validating if this session is valid or not
		 */
		if (new DataBlock().sessionValidation()) {
			System.out.println(new DataBlock().sessionValidation());
			out.println("<body>\r\n" + "<form action=\"http://localhost:8080/Banking/index.html\">\r\n"
					+ "        <h2>Your Login Session has expired...</h2>\r\n"
					+ "        <input type=\"submit\" value=\"Login\" />\r\n" + "</form>\r\n" + "</body>");
		} else {
			
			/*
			 *  Proceeds to collect deposit amount and calls reponseDeposit servlet
			 */
			out.println("<!DOCTYPE html>\r\n" + "<html lang=\"en\">\r\n" + "<head>\r\n" + "    <meta charset=\"UTF-8\">\r\n"
							+ "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n"
							+ "    <meta name=\"viewport\" content=\"width=\\, initial-scale=1.0\">\r\n"
							+ "    <title>Document</title>\r\n" + "</head>\r\n" + "<body>\r\n" + "\r\n"
							+ "    <form action=\"./reponseDeposit\" method=\"POST\">\r\n"
							+ "        Enter the amount to Deposit : <input type=\"numbers\" name=\"d_amount\">\r\n"
							+ "        <br>\r\n" + "        <input type=\"submit\" value=\"Deposit\">\r\n" + "\r\n"
							+ "    </form>\r\n" + "    <form action=\"./Login\" method=\"post\">\r\n"
							+ "        <input type=\"submit\" value=\"Back to menu\">\r\n" + "    </form>\r\n"

							+ "<form action=\"./exitSession\" method=\"post\">\r\n"
							+ "    <input type=\"submit\" value=\"Exit\">\r\n" + "</form>"

							+ "    \r\n" + "</body>\r\n" + "</html>");
		}
	}

}
