package Servlets;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import java.io.PrintWriter;
import java.sql.*;

import DbConnection.DbConnect;

/**
 * Servlet implementation class reponseDeposit
 */
public class reponseDeposit extends HttpServlet {
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();

		/*
		 * Firstly converting the string into the integer using ClassWrappers objects
		 * and then storing them in the local variables
		 * 
		 * Here d_amount refers to the amount that user wants to deposit
		 */
		int d_amount = Integer.parseInt(request.getParameter("d_amount"));

		/*
		 * Establishing basic connections
		 */
		Connection con;
		Statement stmt;

		try {

			if (new DataBlock().sessionValidation()) {

				out.println("<body>\r\n" + "    <form action=\"http://localhost:8080/Banking/index.html\">\r\n"
						+ "        <h2>Your Login Session has expired...</h2>\r\n"
						+ "        <input type=\"submit\" value=\"Login\" />\r\n" + "    </form>\r\n" + "</body>");
			} else {

				/*
				 * Establising basic connections
				 */
				con = DbConnect.connect();
				stmt = con.createStatement();
				/*
				 * Trying to get the amount using username accessing from getters and setters
				 * 
				 * rs.next() -> will point to the next available memeory address
				 */
				ResultSet rs = stmt.executeQuery(
						"SELECT * FROM jsw.login WHERE username=\"" + new DataBlock().getUsername() + "\";");
				rs.next();

				/*
				 * Updating the amount available in the user account with the d_amount
				 */
				stmt.executeUpdate("UPDATE jsw.login SET balance=" + (rs.getInt(9) + d_amount) + " WHERE username=\""
						+ new DataBlock().getUsername() + "\";");

				/*
				 * Closing the connection
				 */
				con.close();

				/*
				 * Functionalities : 1) requestDeposit 2) Home 3) Exit
				 */
				out.println("<!DOCTYPE html>\r\n" + "<html lang=\"en\">\r\n" + "<head>\r\n"
						+ "    <meta charset=\"UTF-8\">\r\n"
						+ "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n"
						+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
						+ "    <title>Deposit</title>\r\n" + "</head>\r\n" + "<body>\r\n" + "    <h2> " + d_amount
						+ " Amount Deposited</h2>\r\n"

						+ "    <form action=\"./requestDeposit\" method=\"post\">\r\n"
						+ "        <input type=\"submit\" value=\"Click to Deposit More\">\r\n" + "    </form>\r\n"

						+ "    <form action=\"./Login\" method=\"post\">\r\n"
						+ "        <input type=\"submit\" value=\"Home\">\r\n" + "    </form>\r\n"

						+ "<form action=\"./exitSession\" method=\"post\">\r\n"
						+ "    <input type=\"submit\" value=\"Exit\">\r\n" + "</form>"

						+ "\r\n" + "</body>\r\n" + "</html>");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
