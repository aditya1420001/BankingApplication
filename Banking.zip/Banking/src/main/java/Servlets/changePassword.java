package Servlets;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

import DbConnection.DbConnect;

import java.io.PrintWriter;

/**
 * Servlet implementation class changePassword
 */
public class changePassword extends HttpServlet {
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();

		/*
		 * Establishing basic connections
		 */
		Connection con;
		Statement stmt;

		if (new DataBlock().sessionValidation()) {

			out.println("<body>\r\n" + "    <form action=\"http://localhost:8080/Banking/index.html\">\r\n"
					+ "        <h2>Your Login Session has expired...</h2>\r\n"
					+ "        <input type=\"submit\" value=\"Login\" />\r\n" + "    </form>\r\n" + "</body>");
		} else {

			try {
				con = DbConnect.connect();
				stmt = con.createStatement();

				ResultSet rs = stmt.executeQuery(
						"select pwd from jsw.login where username=\"" + new DataBlock().getUsername() + "\";");
				rs.next();

				if (((request.getParameter("oldpwd").equals(rs.getString(1))))) {

					if (((request.getParameter("newpwd1") != null) && (request.getParameter("newpwd1") != ""))
							&& (request.getParameter("newpwd1").equals(request.getParameter("newpwd2")))) {
						
						if(request.getParameter("newpwd1").length()>5) {

						stmt.executeUpdate("update jsw.login set password=\"" + request.getParameter("newpwd1")
								+ "\" where username=\"" + new DataBlock().getUsername() + "\";");

						out.println(
								"You have changed your password successfully.<br> Please re-login to access your account");
						new DataBlock().setUsername(null);
						out.println("<form action=\"http://localhost:8080/Banking/index.html\" method=\"post\">\r\n"
								+ "<input type=\"submit\" value=\"Re-Login\">\r\n" + "</form>");
						}
						else {
							response.sendRedirect("http://localhost:8080/Banking/changePassword/lengthHandler.html");
						}

					}
				}

				con.close();
			}

			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
