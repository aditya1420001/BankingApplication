package Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import java.sql.*;

import DbConnection.DbConnect;

/**
 * Servlet implementation class checkBalance
 */
public class checkBalance extends HttpServlet {
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();

		Connection con;
		Statement stmt;
		ResultSet rs;

		if (new DataBlock().sessionValidation()) {
			System.out.println(new DataBlock().sessionValidation());
			out.println("<body>\r\n" + "    <form action=\"http://localhost:8080/Banking/index.html\">\r\n"
					+ "        <h2>Your Login Session has expired...</h2>\r\n"
					+ "        <input type=\"submit\" value=\"Login\" />\r\n" + "    </form>\r\n" + "</body>");
		} else {

			try {
				if (new DataBlock().sessionValidation()) {
					System.out.println(new DataBlock().sessionValidation());
					out.println("<body>\r\n" + "    <form action=\"http://localhost:8080/Banking/index.html\">\r\n"
							+ "        <h2>Your Login Session has expired...</h2>\r\n"
							+ "        <input type=\"submit\" value=\"Login\" />\r\n" + "    </form>\r\n" + "</body>");
				} else {

					con = DbConnect.connect();

					stmt = con.createStatement();

					rs = stmt.executeQuery(
							"select balance from jsw.login where username=\"" + new DataBlock().getUsername() + "\";");

					rs.next();

					System.out.println(rs.getInt(1));

					out.println("<body>\r\n" + "    Your Balance is : " + rs.getInt(1) + "\r\n" + "<br>"
							+ "<form action=\"./Login\" method=\"post\">\r\n"
							+ "<input type=\"submit\" value=\"Menu\">\r\n" + "</form>"

							+ "<form action=\"./exitSession\" method=\"post\">\r\n"
							+ "    <input type=\"submit\" value=\"Exit\">\r\n" + "</form>"

							+ "</body>");

					con.close();
				}

			} catch (Exception e) {

				System.out.println(e);
			}
		}
	}
}