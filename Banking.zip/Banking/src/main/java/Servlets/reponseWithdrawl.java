package Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import DbConnection.DbConnect;

/**
 * Servlet implementation class reponseWithdrawl
 */
public class reponseWithdrawl extends HttpServlet {
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();
		
		/*
		 * Storing w_amount variable got the html page in the local varaible
		 */
		int w_amount = Integer.parseInt(request.getParameter("w_amount"));

		/*
		 * Establishing basic connections
		 */
		Connection con;
		Statement stmt;

		try {
			/*
			 * calling a function from DataBlock class 
			 * will return if private static variable is pointing to null or other value
			 * 
			 * 1) if null -> means session is invalid
			 * 2) not null -> means session is valid
			 */
			if (new DataBlock().sessionValidation()) {
				out.println("<body>\r\n" + "    <form action=\"http://localhost:8080/Banking/index.html\">\r\n"
						+ "        <h2>Your Login Session has expired...</h2>\r\n"
						+ "        <input type=\"submit\" value=\"Login\" />\r\n" + "    </form>\r\n" + "</body>");
			} else {
				
				/*
				 * Establishing basic connections
				 */
				con = DbConnect.connect();
				stmt = con.createStatement();

				/*
				 * Storing the result in rs object
				 */
				ResultSet rs=stmt.executeQuery("SELECT * FROM jsw.login WHERE username=\"" + new DataBlock().getUsername() + "\";");
				rs.next();

				/*
				 * Checking if customer's available balance is elligible for withdrawl or not
				 */
				if (w_amount <= rs.getInt(9) && (w_amount > 0)) {
					
					stmt.executeUpdate("UPDATE jsw.login SET balance=" + (rs.getInt(9) - w_amount) + " where username=\""
							+ new DataBlock().getUsername() + "\";");
					
					out.println(""
							
							+ "<form action=\"./Login\" method=\"post\">\r\n" + "Withdrawl Successful<br>"
							+ "<input type=\"submit\" value=\"Menu\">\r\n" + "</form>"
							
							+ "<form action=\"./requestWithdrawl\" method=\"post\">\r\n"
							+ "    <input type=\"submit\" value=\"Withdraw more\">\r\n" + "</form>"

							+ "<form action=\"./exitSession\" method=\"post\">\r\n"
							+ "    <input type=\"submit\" value=\"Exit\">\r\n" + "</form>");
					
				}
				// 0 can't be drawn
				else if (w_amount == 0) {
					out.println("<body> <h2>0 if invalid input. Pls go back </h2>"

							+ "    <form action=\"./requestWithdrawl\" method=\"post\">\r\n"
							+ "        <input type=\"submit\" value=\"Click to enter valid amount\">\r\n"
							+ "    </form>\r\n"

							+ "</body>");
				}
				// if balance is insufficient shows path to login servlet
				else {
					out.println("<form action=\"./Login\" method=\"post\">\r\n" + "Insufficient Balance"
							+ "	<input type=\"submit\" value=\"Menu\">\r\n" + "	</form>" + ""
							+ "<form action=\"./requestWithdrawl\" method=\"post\">\r\n"
							+ "        <input type=\"submit\" value=\"Click to enter valid amount\">\r\n"
							+ "    </form>\r\n" + "" + "<form action=\"./exitSession\" method=\"post\">\r\n"
							+ "    <input type=\"submit\" value=\"Exit\">\r\n" + "</form>");
				}
				con.close();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
