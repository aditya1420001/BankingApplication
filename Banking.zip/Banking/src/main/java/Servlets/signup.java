package Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.security.*;

import DbConnection.DbConnect;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class signup
 */
public class signup extends HttpServlet {
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();
		Connection con;
		ResultSet rs;
		String query;
		PreparedStatement ps;

		try {
			/*
			 * Establishing basic connections
			 */
			con = DbConnect.connect();

			/*
			 * Collection Query result in rs using ResultSet
			 */
			query = "SELECT username FROM jsw.login WHERE username=?";

			ps = con.prepareStatement(query);
			ps.setString(1, request.getParameter("id"));

			rs = ps.executeQuery();

			/*
			 * if the result is null -> it means that there is no user with the given
			 * username
			 */
			if (rs.next() == false) {
				/*
				 * Checking various cases of passwords
				 */
				if (((request.getParameter("password1") != null) && (request.getParameter("password1") != ""))
						&& (request.getParameter("password1").equals(request.getParameter("password2")))) {

					/*
					 * Updating in the database
					 */
					if (request.getParameter("password1").length() >= 6) {
						query = "INSERT INTO login(username, pwd, first_name, last_name, contact_no, gender, country) values(?, ?, ?, ?, ?, ?, ?);";

						ps = con.prepareStatement(query);

						ps.setString(1, request.getParameter("id"));
						ps.setString(2, request.getParameter("password1"));
						ps.setString(3, request.getParameter("first_name"));
						ps.setString(4, request.getParameter("last_name"));
						ps.setString(5, request.getParameter("contact"));
						ps.setString(6, request.getParameter("gender"));
						ps.setString(7, request.getParameter("country"));

						ps.executeUpdate();

						/*
						 * To know if the user is created or not. (Just for Programmers)
						 */
						System.out.println("user is createdd");

						/*
						 * Connection is closed
						 */
						con.close();

						/*
						 * It automatically redirects to the login page(index.html)
						 * 
						 */
						response.sendRedirect("http://localhost:8080/Banking/index.html");
						
					} else {
						out.println("Password must be greater than 6 letters. please go back");
					}
				} else {
					out.println("Check your password. Please go back");
				}
			} else {
				out.println("This user already exists. Please go back");
			}
			/*
			 * If not closed in inner loop, connections closes here
			 */
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
