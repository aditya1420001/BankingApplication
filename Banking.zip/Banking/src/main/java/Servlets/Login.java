package Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import DbConnection.DbConnect;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Creation of required objects inorder to perform function of servlet
		PrintWriter out = response.getWriter();
		Connection con;
		Statement stmt;

		try {
			/*
			 * Establishing connctions from the package DbConnect throught connect()
			 * function
			 * 
			 */
			con = DbConnect.connect();
			stmt = con.createStatement();
			System.out.println(con);

			/*
			 * Creating a local variable which is linked from the form parameters only
			 * 
			 * if the form parameters are null then -> u_name = null
			 */

			String u_name = request.getParameter("id");
			if (new DataBlock().getUsername()!=null){
				u_name = new DataBlock().getUsername();
			}
			
			/*
			 * Authenticating with u_name or username (private variable from DataBlock
			 * class)
			 * 
			 * Accessing private variables by creating getters and setters
			 */
			if ((u_name != null) || (new DataBlock().getUsername() != null)) {
				
				/*
				 * Fetching the username{u_name -> got parameters from index.html} form the
				 * table to authenticate
				 */
				ResultSet rs = stmt.executeQuery("select * from jsw.login where username=\"" + u_name + "\";");

				/*
				 * Here password authentication is done in two ways
				 * 
				 * 1) Either by fetching password from index.html 2) Checking if private
				 * username variable is set to other than null (if not set to null means the
				 * session is still in active state)
				 * 
				 */
				if (((rs.next()) && (rs.getString(3).equals(request.getParameter("password"))))
						|| (new DataBlock().getUsername() != null)) {

					/*
					 * Closing the con obj to overcome security risks which misleads data integrity
					 */
					String f_name = rs.getString(4);
					

					/*
					 * If the user is newly logged in then the private static username variable is
					 * set to the customer's username This private static variable will help in
					 * maintaining session of the customer though he revisits homepage from any page
					 * 
					 * This is achieved through getters and setters
					 */
					if (new DataBlock().getUsername() == null) {
						new DataBlock().setUsername(u_name);
					}

					/*
					 * Creating various applications to perform various operations
					 * 
					 * 1) requestWithdrawl -> reponseWithdrawl 2) requestDeposit -> responseDeposit
					 * 3) checkBalance 4) exitSession
					 * 
					 */

					out.println(
							"<!DOCTYPE html>\r\n" + "<html>\r\n" + "<head>\r\n" + "<meta charset=\"ISO-8859-1\">\r\n"
									+ "<title>Home</title>\r\n" + "</head>\r\n" + "<body>\r\n" + "    \r\n" + ""
									/*
									 * accessing username(private static variable from DataBlock class) to fetch
									 * data from tables to update accordingly
									 * 
									 * this variable can be accessed from anywhere until and unless the exit button
									 * is clicked
									 */
									+ "<h3>Hi " + f_name + " !</h3>"
									+ "Your A/c No : " + rs.getInt(1)
									
									+ "<form action=\"./requestWithdrawl\" method=\"post\">\r\n"
									+ "    <input type=\"submit\" value=\"Withdrawl\">\r\n" + "</form>\r\n" + "\r\n"
									
									+ "" + "<form action=\"./requestDeposit\" method=\"post\">\r\n"
									+ "    <input type=\"submit\" value=\"Deposit\">\r\n" + "</form>\r\n" + "\r\n" + ""
									
									+ "<form action=\"./checkBalance\" method=\"post\">\r\n"
									+ "    <input type=\"submit\" value=\"Check Balance\">\r\n" + "</form>\r\n" + "\r\n"
									+ ""

									+ "<form action=\"http://localhost:8080/Banking/changePassword.html\" method=\"post\">\r\n"
									+ "    <input type=\"submit\" value=\"Change Password\">\r\n" + "</form>"

									+ "<form action=\"./exitSession\" method=\"post\">\r\n"
									+ "    <input type=\"submit\" value=\"Exit\">\r\n" + "</form>"

									+ "\r\n" + "" + "</body>\r\n" + "</html>");
				}
				
				else {
					/*
					 * Incase of password authentication is wrong (or) the username(private static
					 * variable) is set to null that means the session is invalid
					 */
					response.sendRedirect("http://localhost:8080/Banking/index.html");
				}
			} else {
				/*
				 * Incase of username is not found this will also redirect to the index.html
				 */
				response.sendRedirect("http://localhost:8080/Banking/index.html");
			}
			con.close();

		} catch (Exception e) {
			out.println("session expired");
			System.out.println(e);
		}
	}

}
