package Servlets;

public class DataBlock {

	private static String username = null;

	public String getUsername() {
		return username;
	}

	protected void setUsername(String username) {
		DataBlock.username = username;
	}

	boolean sessionValidation() {
		if (username == null) {
			return true;
		} else {
			System.out.println(username);
			return false;
		}
	}

}
